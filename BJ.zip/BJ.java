
import java.util.Scanner;

public class BJ {
	public static Scanner input = new Scanner(System.in);
	public static int playernum = 0;
	public static int[] card = new int[53];
	public static String[] hand = new String[9];
	public static int[] mark = new int[9];
	public static String[] deck = new String[9];

	public static void main(String[] args) {
		testmode();
		while (playernum < 1 || playernum > 8) {

			System.out.print("How many players? ");
			playernum = input.nextInt();

			if (playernum == 1) {
				System.out.println("");
				System.out.println("Game Start! (" + playernum + " player)");
				System.out.println("======================================");
			} else if (playernum >= 2 && playernum <= 8) {
				System.out.println("");
				System.out.println("Game Start! (" + playernum + " players)");
				System.out.println("======================================");
			} else if (playernum > 8) {
				System.out.println("Can't over 8 people to join the game");
			} else if (playernum < 1) {
				System.out.println("Number of players must be greater than or equal to 1");
			}
		}
		firstround();
		playround();
		finalresult();

	}

	public static String gencard(int player) {
		String suit, value, playercard;

		int rand = (int) (Math.random() * 52) + 1;

		while (card[rand] == 1) {
			rand = (int) ((Math.random()) * 52) + 1;
		}

		card[rand] = 1;

		if (rand <= 13) {
			suit = "Spade";
		} else if (rand <= 26) {
			suit = "Heart";
		} else if (rand <= 39) {
			suit = "Club";
		} else {
			suit = "Diamond";
		}

		rand %= 13;

		if (rand == 0) {
			value = "King";
		} else if (rand == 12) {
			value = "Queen";
		} else if (rand == 11) {
			value = "Jack";
		} else if (rand == 10) {
			value = "10";
		} else if (rand == 1) {
			value = "Ace";
		} else {
			value = "0" + String.valueOf(rand);
		}

		int ace = 0;

		rand %= 13;

		if (rand == 0 || rand == 10 || rand == 11 || rand == 12) {
			mark[player] += 10;
		} else if (rand == 1) {
			ace += 1;
			for (int i = 0; i < ace; i++) {
				if (mark[player] <= 10) {
					mark[player] += 11;
				} else if (mark[player] > 10) {
					mark[player] += 1;
				}
			}
		} else {
			mark[player] += rand;
		}

		playercard = suit + ":" + value + " ";

		hand[player] += playercard;

		return playercard;
	}

	public static void getcard(int i) {

		int decision = 1;

		while (mark[i] < 21) {
			System.out.print("Player" + i + ", do you want to Stand or Hit?(0-Stand , 1-Hit) ");
			decision = input.nextInt();

			if (decision == 1) {
				gencard(i);
				System.out.println("Player" + i + "'s Hand:[ " + hand[i] + "]");
			} else if (decision == 0) {
				break;
			} else if (decision != 0 && decision != 1) {
				System.out.println("You must input 0 or 1!");
			}
		}
	}

	// check the point
	public static void check(int i) {

		if (mark[i] > 21) {
			System.out.println("Bust!");
		} else if (mark[i] == 21) {
			System.out.println("Blackjack!");
		}
	}

	public static void decide(int i) {
		// check the point
		if (mark[i] > 21) {
			System.out.println("Bust!");
		} else if (mark[i] == 21) {
			System.out.println("Blackjack!");
		} else if (mark[i] == mark[0]) {
			System.out.println("Push!");
		} else if (mark[i] > mark[0] && mark[i] < 21 || mark[0] > 21) {
			System.out.println("Win!");
		} else if (mark[i] < mark[0] && mark[0] < 21) {
			System.out.println("Lose!");
		}
	}

	public static void getPoints(int i) {

		int choice = 1;

		System.out.print("Player" + i + ",do you want to get the ponits?(0-NO , 1-YES)");

		choice = input.nextInt();

		if (choice == 1) {
			System.out.println("The points for [" + hand[i] + "])is " + mark[i]);
		}

		while (choice != 1 && choice != 0) {
			System.out.println("You must input 0 or 1!");
			System.out.print("Player" + i + ",do you want to get the ponits?(0-NO , 1-YES)");
			choice = input.nextInt();
		}
	}

	public static void testmode() {
		// choose go to testmode
		int t; // Enter the number go to test mode
		int b;
		int c; // The number of what you want to add the card number of kinds
		System.out.print("Go To Test Mode (0-No, 1-Yes) : ");
		t = input.nextInt();

		if (t == 0) {

		} else if (t > 1) {
			System.out.println("You must input 0 or 1!");
			System.out.print("Go To Test Mode (0-No, 1-Yes) : ");
			t = input.nextInt();
		} else if (t < 0) {
			System.out.println("You must input 0 or 1!");
			System.out.print("Go To Test Mode (0-No, 1-Yes) : ");
			t = input.nextInt();
		} else if (t == 1) {

			for (b = 1; b >= 1; b++) {
				System.out.print("Input Card" + b + " in your deck (0 to end): ");
				c = input.nextInt();
				if (c == 0) {
					break;
				} else if (c > 52) {
					System.out.println("Your enter is outside!");
				}
			}
		} else if (t == 0) {

		}

	}

	public static void firstround() {
		for (int i = 0; i <= playernum; i++) {
			hand[i] = "";
		}
		for (int i = 1; i <= playernum; i++) {
			gencard(i);
		}

		gencard(0);

		for (int i = 1; i <= playernum; i++) {
			deck[i] = gencard(i);
			System.out.println("Player" + i + "'s Hand: [ Unknown " + deck[i] + "]");
		}

		deck[0] = gencard(0);

		System.out.println("Dealer's Hand: [ Unknown " + deck[0] + "]");
		System.out.println("");

	}

	public static void playround() {
		System.out.println("Players' Round (" + playernum + " players)");
		System.out.println("======================================");

		for (int i = 1; i <= playernum; i++) {
			System.out.println("Player" + i + "'s Hand:[ " + hand[i] + "]");
			getcard(i);
			check(i);
		}

		System.out.println("");
		System.out.println("Dealer's Round (" + playernum + " players)");
		System.out.println("======================================");
		System.out.println("Dealer's Hand:[ " + hand[0] + "]");

		while (mark[0] < 17) {
			gencard(0);
			System.out.println("Lower than 17, add new cards!");
			System.out.println("Dealer's Hand:[ " + hand[0] + "]");
		}

		check(0);
	}

	public static void finalresult() {
		System.out.println("");
		System.out.println("Final Result (" + playernum + " players)");
		System.out.println("======================================");

		for (int i = 1; i <= playernum; i++) {
			System.out.println("Player" + i + "'s Hand:[ " + hand[i] + "]");
			if (mark[i] > 21) {
				System.out.println("lose");
			} else if (mark[i] >= 2 && mark[i] <= 21) {
				getPoints(i);
				decide(i);
			}
		}

		System.out.println("Dealer's Hand:[ " + hand[0] + "]");

		check(0);
	}
}